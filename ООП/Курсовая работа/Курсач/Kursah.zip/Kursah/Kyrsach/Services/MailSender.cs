﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Kyrsach
{
    public class MailSender
    {
        private Random rand = new Random();
        public int code;
        public string SaveLog;

        public void SendEmail()
        {
            code = rand.Next(1000, 9999);
            code = 1;
            Application.Current.Resources["Code"] = code;


            var mail = new MailMessage();
            mail.From = new MailAddress("cwalletinfo@yandex.by");
            mail.To.Add(Application.Current.Resources["SaveLogin"].ToString());
            mail.Subject = "Код для авторизации";
            mail.Body = "Используйте этот код для авторизации в приложеие: " + code.ToString();

            var SmtpServer = new SmtpClient();
            SmtpServer.Host = "smtp.yandex.ru";
            SmtpServer.Port = 587;
            SmtpServer.EnableSsl = true;
            SmtpServer.Credentials = new NetworkCredential("cwalletinfo@yandex.by", "iuppfdiexzxjjorb");


            try
            {
                SmtpServer.Send(mail);
                MessageBox.Show("Письмо отправлено");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка отправки письма");
            }

        }

        public void SendNotification(TransactionsList trans)
        {

            var mail = new MailMessage();
            mail.From = new MailAddress("cwalletinfo@yandex.by");
            mail.To.Add(Application.Current.Resources["SaveLogin"].ToString());

            mail.Subject = "Оповещение о переводе";

            mail.Body = "Совершен перевод на сумму: " + trans.Amount.ToString() + "\n";
            mail.Body += "С адреса: " + trans.FromAdress.ToString() + "\n";
            mail.Body += "На адрес: " + trans.ToAdress.ToString() + "\n";
            mail.Body += "Дата: " + trans.Date.ToString() + "\n";
            mail.Body += "Комисия: " + trans.Fee.ToString() + "\n";
            mail.Body += "Цена в USD: " + trans.UsdPrice.ToString() + "\n";
            mail.Body += "Спасибо что вы с нами!";


            var SmtpServer = new SmtpClient();
            SmtpServer.Host = "smtp.yandex.ru";
            SmtpServer.Port = 587;
            SmtpServer.EnableSsl = true;
            SmtpServer.Credentials = new NetworkCredential("cwalletinfo@yandex.by", "iuppfdiexzxjjorb");

            try
            {
                SmtpServer.Send(mail);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка отправки письма");
            }
        }

    }

}